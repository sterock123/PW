


(function () {
  const showTip = (el) => {
    if (el._tip) return;
    const text = el.getAttribute('data-tip');
    if (!text) return;
    const tip = document.createElement('div');
    tip.className = 'tooltip-float';
    tip.textContent = text;
    document.body.appendChild(tip);
    // dove
    const rect = el.getBoundingClientRect();
    const tipRect = tip.getBoundingClientRect();
    let top = window.scrollY + rect.bottom + 8;
    let left = window.scrollX + rect.left;
    if (left + tipRect.width > window.scrollX + window.innerWidth - 8) {
      left = window.scrollX + rect.right - tipRect.width;
    }
    if (rect.bottom + tipRect.height + 12 > window.innerHeight) {
      top = window.scrollY + rect.top - tipRect.height - 8;
    }
    tip.style.position = 'absolute';
    tip.style.top = `${top}px`;
    tip.style.left = `${left}px`;
    tip.style.zIndex = 9999;
    tip.style.maxWidth = '320px';
    tip.style.background = '#ffffff';
    tip.style.border = '1px solid #e5e7eb';
    tip.style.boxShadow = '0 8px 24px rgba(2, 6, 23, 0.12)';
    tip.style.borderRadius = '10px';
    tip.style.padding = '8px 10px';
    tip.style.fontSize = '12px';
    tip.style.lineHeight = '1.35';
    tip.style.color = '#111827';
    tip.style.whiteSpace = 'pre-line';

    el._tip = tip;
  };

  const hideTip = (el) => {
    if (!el._tip) return;
    el._tip.remove();
    el._tip = null;
  };

  // versione desktop: hover/focus
  document.addEventListener('mouseover', (e) => {
    const el = e.target.closest('.has-tip');
    if (el) showTip(el);
  });
  document.addEventListener('mouseout', (e) => {
    const el = e.target.closest('.has-tip');
    if (el) hideTip(el);
  });
  document.addEventListener('focusin', (e) => {
    const el = e.target.closest('.has-tip');
    if (el) showTip(el);
  });
  document.addEventListener('focusout', (e) => {
    const el = e.target.closest('.has-tip');
    if (el) hideTip(el);
  });

  // versione mobile
  document.addEventListener('click', (e) => {
    const el = e.target.closest('.has-tip');
    //disattivare versione mobile
    if (!el) {
      document.querySelectorAll('.has-tip').forEach(hideTip);
      return;
    }
    if (el._tip) hideTip(el); else showTip(el);
  });
})();
